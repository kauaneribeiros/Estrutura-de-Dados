
#ifndef NUMPRIMO_H
#define NUMPRIMO_H

class NumPrimo {
public:
    NumPrimo();
    NumPrimo(const NumPrimo& orig);
    virtual ~NumPrimo();
    
    int i, resultado=0, num;
    
    void VerificaNum();
    void MostrarNum();
    
private:

};

#endif /* NUMPRIMO_H */

