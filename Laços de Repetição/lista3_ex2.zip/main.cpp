#include <cstdlib>
#include "NumPrimo.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    NumPrimo obj;
    obj.VerificaNum();
    obj.MostrarNum();

    return 0;
}

