#include <iostream>
#include "NumPrimo.h"

using namespace std;

NumPrimo::NumPrimo() {
}

NumPrimo::NumPrimo(const NumPrimo& orig) {
}

NumPrimo::~NumPrimo() {
}

void NumPrimo::VerificaNum(){
    
        this->num=num;
        this->i=i; // i é o contador
        
        // vamos verificar se o valor de i é igual 1. Se for igual a 1, então as variáveis maior e menor passam a ter o valor do número digitado
        
        cout << "Digite um número: " << endl;
        cin >> this->num;
 

}


void NumPrimo::MostrarNum(){
    
    for (i = 2; i <= this->num / 2; i++) {
    if (this->num % i == 0) {
       this->resultado++;
       break;
    }
 }
 
 if (this->resultado == 0)
    cout << "é um número primo\n" << this->num;
 else
    cout << "não é um número primo\n" << this->num;

}