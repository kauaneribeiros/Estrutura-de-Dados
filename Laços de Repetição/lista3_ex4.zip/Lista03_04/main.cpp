/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Stofa
 *
 * Created on 25 de Setembro de 2022, 15:43
 */

#include <iostream>
#include <cstdlib>

#include "FibonacciAlg.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    FibonacciAlg obj;
    obj.lerDados();
    return 0;
}