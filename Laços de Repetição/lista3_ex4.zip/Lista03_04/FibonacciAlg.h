/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   FibonacciAlg.h
 * Author: Stofa
 *
 * Created on 25 de Setembro de 2022, 15:43
 */

#ifndef FIBONACCIALG_H
#define FIBONACCIALG_H

class FibonacciAlg {
public:
    FibonacciAlg();
    FibonacciAlg(const FibonacciAlg& orig);
    virtual ~FibonacciAlg();
    
    void lerDados();
    int imprimirDados(int n, int t1=0, int t2=1, int nextTerm=0);
    
private:

};

#endif /* FIBONACCIALG_H */