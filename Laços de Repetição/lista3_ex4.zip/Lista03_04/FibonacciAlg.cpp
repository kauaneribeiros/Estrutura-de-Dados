/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   FibonacciAlg.cpp
 * Author: Stofa
 * 
 * Created on 25 de Setembro de 2022, 15:43
 */

#include <iostream>
#include "FibonacciAlg.h"

using namespace std;

FibonacciAlg::FibonacciAlg() {
}

FibonacciAlg::FibonacciAlg(const FibonacciAlg& orig) {
}

FibonacciAlg::~FibonacciAlg() {
}

void FibonacciAlg::lerDados() {
    cout << "Algoritimo de Fibonacci: " << endl;
}

int FibonacciAlg::imprimirDados(int n, int t1=0, int t2=1, int nextTerm=0) {
    for (int i = 1; i <= n; ++i) {
        if(i == 1) {
            cout << t1 << ", ";
            continue;
        }
        if(i == 2) {
            cout << t2 << ", ";
            continue;
        }
        nextTerm = t1 + t2;
        t1 = t2;
        t2 = nextTerm;
        
        cout << nextTerm << ", ";
    }
    return 0;
}