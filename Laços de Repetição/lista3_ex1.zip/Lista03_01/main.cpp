/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Stofa
 *
 * Created on 26 de Setembro de 2022, 09:18
 */

#include <iostream>
#include <cstdlib>

#include "candidatosAlg.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    candidatosAlg obj;
    obj.lerDados();
    return 0;
}