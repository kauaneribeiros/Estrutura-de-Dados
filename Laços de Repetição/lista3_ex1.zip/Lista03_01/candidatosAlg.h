/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   candidatosAlg.h
 * Author: Stofa
 *
 * Created on 26 de Setembro de 2022, 09:18
 */

#ifndef CANDIDATOSALG_H
#define CANDIDATOSALG_H

class candidatosAlg {
public:
    candidatosAlg();
    candidatosAlg(const candidatosAlg& orig);
    virtual ~candidatosAlg();
    void lerDados();
    float imprimirDados(int candidato, int candidatoa, int candidatob, int candidatoc, int candidatod);
private:

};

#endif /* CANDIDATOSALG_H */