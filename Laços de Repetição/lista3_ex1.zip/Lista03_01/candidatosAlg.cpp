/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   candidatosAlg.cpp
 * Author: Stofa
 * 
 * Created on 26 de Setembro de 2022, 09:18
 */

#include <iostream>
#include "candidatosAlg.h"

using namespace std;

candidatosAlg::candidatosAlg() {
}

candidatosAlg::candidatosAlg(const candidatosAlg& orig) {
}

candidatosAlg::~candidatosAlg() {
}

void candidatosAlg::lerDados() {
    int candidato;
    cout << "Digite o número correspondente ao seu candidato: \n1\n2\n3\n4" << endl;
    cin >> candidato;
}

float candidatosAlg::imprimirDados(int candidato, int candidatoa, int candidatob, int candidatoc, int candidatod) {
    switch (candidato) {
        case 1:
            candidatoa= candidatoa + 1;
            break;
        case 2:
            candidatob= candidatob + 1;
            break;
        case 3:
            candidatoc= candidatoc + 1;
            break;
        case 4:
            candidatod= candidatod + 1;
            break;
    }
}