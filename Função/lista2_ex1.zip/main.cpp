#include <cstdlib>
#include "exUm.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    exUm obj;
    obj.LerDados();
    return 0;
}

