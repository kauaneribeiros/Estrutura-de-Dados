#include "exUm.h"
#include <iostream>

using namespace std;

exUm::exUm() {
}

exUm::exUm(const exUm& orig) {
}

exUm::~exUm() {
}

int exUm::ImprimirDados(int a, int b){
    int a, b, menor;
    
    if (a < b){
    menor = b;
} else 
    menor = a;
    
    return menor;
    
}

void exUm::LerDados(){
    int A, B, men;
cout << "Informe um primeiro valor inteiro: " << endl;
    cin >> A;
    cout << "Informe um primeiro valor inteiro: " << endl;
    cin >> B;
    

    cout << "O menor número digitado foi: " << men << endl;




}