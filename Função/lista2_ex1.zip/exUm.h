#ifndef EXUM_H
#define EXUM_H

class exUm {
public:
    exUm();
    exUm(const exUm& orig);
    virtual ~exUm();
        int ImprimirDados(int a, int b);
        void LerDados();

    
private:

};

#endif /* EXUM_H */

