#include <cstdlib>
#include "cAltura.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    cAltura obj;
    obj.LerDados();
    
    return 0;
}

