#include <cstdlib>
#include "cPedido.h"

using namespace std;


int main(int argc, char** argv) {
    
    cPedido obj;
    obj.lerDadosPedido();

    return 0;
}

