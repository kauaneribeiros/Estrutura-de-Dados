#ifndef VOLUMEESFERA_H
#define VOLUMEESFERA_H

class volumeEsfera {
public:
    
    float raio;
    
    volumeEsfera();
    volumeEsfera(const volumeEsfera& orig);
    virtual ~volumeEsfera();
    
    void LerDados();
    
    float calcularVolume(float raio);    
private:

};

#endif /* VOLUMEESFERA_H */

