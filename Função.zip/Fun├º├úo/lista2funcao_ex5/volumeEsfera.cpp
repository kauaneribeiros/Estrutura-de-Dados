#include "volumeEsfera.h"
#include<iostream>
#include<math.h>

using namespace std;

volumeEsfera::volumeEsfera() {
}

volumeEsfera::volumeEsfera(const volumeEsfera& orig) {
}

volumeEsfera::~volumeEsfera() {
}

void volumeEsfera::LerDados(){
    
    cout << "Digite o raio da esfera: " << endl;
    cin >> this->raio;
    cout << this->calcularVolume(raio);

}

float volumeEsfera::calcularVolume(float raio){
    
    float volume = 4*3 * 3.14 * pow(this->raio, 3);
    return volume;
    
}