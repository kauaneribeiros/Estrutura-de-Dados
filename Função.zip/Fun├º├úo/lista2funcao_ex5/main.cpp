#include <cstdlib>
#include "volumeEsfera.h"

using namespace std;

int main(int argc, char** argv) {
    
    volumeEsfera *objRaio = new volumeEsfera();
    objRaio->LerDados();

    return 0;
}

