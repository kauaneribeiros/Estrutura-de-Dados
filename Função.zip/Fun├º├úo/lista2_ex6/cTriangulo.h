#ifndef CTRIANGULO_H
#define CTRIANGULO_H

class cTriangulo {
public:
    
    float x, y, z;
    
    cTriangulo();
    cTriangulo(const cTriangulo& orig);
    virtual ~cTriangulo();
    
    void LerDados();
    void ApresentarDados();
    
private:

};

#endif /* CTRIANGULO_H */

