#include "cTriangulo.h"
#include<iostream>

using namespace std;

cTriangulo::cTriangulo() {
}

cTriangulo::cTriangulo(const cTriangulo& orig) {
}

cTriangulo::~cTriangulo() {
}

void cTriangulo::LerDados(){
    cout << "Informe o primeiro lado: " << endl;
    cin>>this->x;
    cout << "Informe o segundo lado: " << endl;
    cin>>this->y;
     cout << "Informe o terceiro lado: " << endl;
    cin>>this->z;
    
    this->ApresentarDados();
    
}

void cTriangulo::ApresentarDados(){

        if((this->x == this->y) && (this->x == this->z))
            cout << "Triângulo Equilatero. " << endl;
        else
            if((this->x == this->y) || (this->x == this->z) || (this->y == this->z))
                cout << "Triângulo Isosceles. " << endl;
            else
                cout << "Triângulo Escaleno. " << endl;
    
}