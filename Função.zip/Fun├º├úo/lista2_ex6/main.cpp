#include <cstdlib>
#include "cTriangulo.h"

using namespace std;

int main(int argc, char** argv) {
    
    cTriangulo obj;
    obj.LerDados();
    
    return 0;
}

