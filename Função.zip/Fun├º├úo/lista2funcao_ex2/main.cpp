#include <cstdlib>
#include "cAluno.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    cAluno *objAluno = new cAluno();
    objAluno->LerDados();
    
    return 0;
}

