#include "cBaskhara.h"
#include<iostream>
#include<math.h>

using namespace std;

cBaskhara::cBaskhara() {
}

cBaskhara::cBaskhara(const cBaskhara& orig) {
}

cBaskhara::~cBaskhara() {
}

void cBaskhara::LereCalcularDados(){ //ler e calcular
    
    cout << "Digite o valor de a: " << endl;
    cin>>this->a;
    cout << "Digite o valor de b: " << endl;
    cin>>this->b;
    cout << "Digite o valor de c: " << endl;
    cin>>this->c;
    
    cout << this->fDelta(this->a, this->b, this->c);

}
int cBaskhara::fDelta(int a, int b, int c){
    
    int delta;
    delta = pow(b,2)-4*a*c;
    return delta;

}