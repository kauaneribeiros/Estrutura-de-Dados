#ifndef CBASKHARA_H
#define CBASKHARA_H

class cBaskhara {
public:
    
    int a, b, c;
    
    cBaskhara();
    cBaskhara(const cBaskhara& orig);
    virtual ~cBaskhara();
    void LereCalcularDados();
    int fDelta(int a, int b, int c);
private:

};

#endif /* CBASKHARA_H */

