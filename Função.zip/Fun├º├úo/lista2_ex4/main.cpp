#include <cstdlib>
#include<iostream>
#include"cBaskhara.h"

using namespace std;

int main(int argc, char** argv) {
    
    cBaskhara*Obj = new cBaskhara();
    Obj->LereCalcularDados();
    int Resultado;
    Resultado = Obj->fDelta(Obj->a, Obj->b, Obj->c);
    cout << Resultado;
    
    return 0;
}

