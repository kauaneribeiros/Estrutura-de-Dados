#include <cstdlib>
#include "cNumero.h"

using namespace std;

int main(int argc, char** argv) {
    
    cNumero obj;
    obj.LerDados();
    
    return 0;
}

